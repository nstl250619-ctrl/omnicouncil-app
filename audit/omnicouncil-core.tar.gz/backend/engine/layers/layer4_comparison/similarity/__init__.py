"""Similarity computation modules."""
