"""AI adapter implementations."""
