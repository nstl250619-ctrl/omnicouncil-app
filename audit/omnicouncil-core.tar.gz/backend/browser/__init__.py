"""Browser engine abstraction layer."""
